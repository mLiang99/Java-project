//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
/**
//Michael Liang 40117394
//COMP 249
// Assignment 2 part 1
// July 26, 2020
 */

/**
 * This program loads and unloads delivery packages in the truck and allows you personalize your truck.
 */
package post_canada;

import java.util.InputMismatchException;
import java.util.Scanner;


public class cargoTest_driver {

	public static void main(String[] args) {
		/**
		 * Welcoming message and menu display
		 */
		System.out.println("Welcome to Corcordia Express Post Service \nWhat would you like to do");

		Scanner keyboard = new Scanner(System.in);
		truck truck1 = null;
		delivery_package packageUnknown = null;
		//menu display
		
		try {
			boolean leave_program = false;
			delivery_package[] masterLoadingList = new delivery_package[200];

			do {
				System.out.println("1. Start a cargo\r\n" + "2. Load the truck with packages\r\n"
						+ "3. Unload a package\r\n" + "4. The number of packages loaded\r\n"
						+ "5. The gross income earned by shipping of the cargo\r\n"
						+ "6. Weight the truck(after it has been completely loaded)\r\n"
						+ "7. Drive the truck to destination\r\n" + "0. To quit\r\n"
						+ "Please enter your choice and press <Enter>:");
				int action = keyboard.nextInt();
				if (action >= 7 || action < 0) {
					throw new InputMismatchException("Please enter a valid choice between 0 to 7");
					
				}
				switch (action) {// create truck object
				case 1:

					System.out.println("input driver name");
					keyboard.nextLine();
					String name = keyboard.nextLine();
					System.out.println("input unloaded weight of the truck");
					int unloaded_weight = keyboard.nextInt();
					System.out.println("input originating city");
					keyboard.nextLine();
					String initial = keyboard.nextLine();
					System.out.println("input destination city");
					String destination = keyboard.nextLine();
					truck1 = new truck(name, initial, destination, unloaded_weight);
					System.out.println("Truck has been created successfully!");
					leave_program = false;
					break;
				case 2:// create a delivery package
					System.out.println("Which type of package would you like to create?\r\n" + "1.letter\r\n"
							+ "2. box\r\n" + "3. wooden crate\r\n" + "4. metal crate\r\n");
					keyboard.nextLine();

					int packageType = keyboard.nextInt();
					System.out.println("Input weight of the package");

					double weight = keyboard.nextInt();

					if (packageType == 1) {

						packageUnknown = new letter(weight);
					

					} else if (packageType == 2) {
						packageUnknown = new box(weight);
					} else if (packageType == 3) {
						packageUnknown = new wood_crate(weight);
					} else if (packageType == 4) {
						packageUnknown = new crate_metal(weight);
					}

					truck1.load(truck1.getLoadingPackage(packageUnknown));
					if(truck1.getLoaded_nb_package()==0){
						truck1.setLoaded_nb_package(1);
					}
					masterLoadingList[truck1.getLoaded_nb_package() - 1] = truck1.getLoadingPackage(packageUnknown);
					leave_program = false;
					break;

				case 3:// unload a specific package from the loaded package
					if(truck1.getLoaded_nb_package()<=0) {
						System.out.println("No current package in the truck");
						break;
					}
					System.out.println("which package would you like to unload from 0 to"
							+ (truck1.getLoaded_nb_package()-1) + " representing the index in the package array");
					int indexToRemove = keyboard.nextInt();
					System.out.println("Successfully remove the package bellow\n");
					truck1.unload_truck(truck1.getLoadingPackage(masterLoadingList[indexToRemove]));
					leave_program = false;
					break;
				case 4://output the number of loaded package
					System.out
							.println("The number of loaded packages in this truck is " + truck1.getLoaded_nb_package());
					break;
				case 5:// output the total income
					System.out.println("Total gross income for this truck is " + truck1.getGross_income());
					break;
				case 6:// output the gross weight
					System.out.println("Gross weight of the truck including the cargo: \n"
							+ (truck1.getUnloaded_weight_lbs() + truck1.getGross_package_weight()) + " lbs" + "(or "
							+ (truck1.getUnloaded_weight_lbs() + truck1.getGross_package_weight()) / 2.205 + " kg)");
					break;
				case 7:// when truck arrives at destination
					System.out.println("Truck from " + truck1.getOrigin_location()
							+ " has arrived successfully to destination in " + truck1.getDestination());
					break;
				case 0:// quit program
					leave_program=true;
					break; 
					
				default:
					System.out.println("Please select a valid choice between 0 to 7");
					leave_program=false;
					
				}// variable leave program will exit the loop when user wants to end the program
			} while (leave_program == false);
			{//ending message
				System.out.println("Thank you for using this software!!!!");
			}
		}

		catch (InputMismatchException e) {
			System.out.println(e.getMessage());
			int action = keyboard.nextInt();
			keyboard.nextLine();
		}
	}


}
