//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;



public class letter extends delivery_package {
	// weight in ounce
/**
 * letter class is a delivery_package
 */
	public letter() {
		super();

	}
	/**
	 * letter constructor with one variable
	 * @param weight
	 */
	public letter(double weight) {
		super(weight);

	}
	/**
	 * copy constructor
	 * @param another_package
	 */
	public letter(letter another_package) {
		super(another_package);

	}
	/**
	 * display object
	 */
	public String toString() {
		return "Package Type: " + getPackageType() + "\nWeight (convert into lbs): " + getWeight()
				+ "\nshipping cost ($): " + getShipping_cost() + "\nTracking Number:"
				+ toStringTrackingNb(getTracking_nb());
	}
	public void calCost() {
		setShipping_cost(getWeight() * 0.05);

	}
	/**
	 * validate weight to see if it could be loaded in the truck
	 */
	public boolean check_weight(double weight) {

		return (weight > 0 && weight <= 32);
	}

	public String getPackageType() {
		return "letter";
	}


	/**
	 * generate tracking number for the letter type package
	 */
	public void generateTrackingNumber() {
		int[] trackingNb = new int[10];

		for (int i = 0; i < 9; i++) {
			trackingNb[i] = (int) (Math.random() * (11 - 0));
		}
		trackingNb[9] = 0;
		setTracking_nb(trackingNb);
	}

}
