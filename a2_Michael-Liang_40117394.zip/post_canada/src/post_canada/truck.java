//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;

public class truck {
	/**
	 * private instance variables for the truck class
	 */
	private String driver_name;
	private String origin_location;
	private String destination;
	private double gross_weight;
	private double unloaded_weight_lbs;
	private double gross_package_weight;
	private delivery_package[] loading;
	private double gross_income;
	private static int loaded_nb_package;

	/**
	 * truck constructor with all main attributes
	 * 
	 * @param driver
	 * @param origin
	 * @param destination
	 * @param initial_weight_lbs
	 */
	public truck(String driver, String origin, String destination, double initial_weight_lbs) {
		this.driver_name = driver;
		this.origin_location = origin;
		this.destination = destination;
		this.unloaded_weight_lbs = initial_weight_lbs;
		this.loading = new delivery_package[200];
		this.gross_weight = getGross_weight();
		this.gross_income = getGross_income();

	}

	
	/**
	 * mutator for changing the weight of the truck
	 * 
	 * @param unloaded_weight_lbs
	 */
	public void setUnloaded_weight_lbs(double unloaded_weight_lbs) {
		this.unloaded_weight_lbs = unloaded_weight_lbs;
	}

	/**
	 * method uses to sum all the packages in the truck
	 * 
	 * @param load
	 * @return double
	 */
	public double total_package_weight_lbs(delivery_package load) {
		double total_package_weight = getGross_package_weight();

		total_package_weight += load.getWeight();

		return this.gross_package_weight = total_package_weight;
	}

	/**
	 * accessor uses to get the the total weight of all packages
	 * 
	 * @return double
	 */
	public double getGross_package_weight() {
		return this.gross_package_weight;
	}

	/*
	 * public void setGross_package_weight(double gross_package_weight) {
	 * this.gross_package_weight = gross_package_weight; }
	 */
	/**
	 * void method to convert truck gross weight into pound
	 * 
	 * @param vehicule_weight_pounds
	 */
	public void toPounds_forTruck(double vehicule_weight_pounds) {
		setUnloaded_weight_lbs(vehicule_weight_pounds);
	}

	/**
	 * void method that convert weight from lbs to kilogram
	 * 
	 * @param vehicule_weight_pounds
	 */
	public void toKilogram_forTruck(double vehicule_weight_pounds) {
		setUnloaded_weight(vehicule_weight_pounds / 2.205);
	}

	/**
	 * setter uses to declare gross weight or to edit
	 * 
	 * @param gross_weight
	 */
	// total weight of the entire truck plus package
	public void setGross_weight(double gross_weight) {
		this.gross_weight = gross_weight;
	}

	/**
	 * getter uses to access gross weight
	 * 
	 * @return double
	 */
	public double getGross_weight() {
		System.out.println(gross_weight);
		return this.gross_weight;
	}

	/**
	 * method uses to calculate total weight in lbs
	 * 
	 * @param x
	 */
	// method uses to calculate gross weight
	public double cal_gross_weight() {
		this.gross_weight = (this.gross_package_weight + this.unloaded_weight_lbs);
		return this.gross_weight;
	}

	// unloaded truck weight
	public double getUnloaded_weight_lbs() {
		return this.unloaded_weight_lbs;
	}

	public void setUnloaded_weight(double unloaded_weight) {
		this.unloaded_weight_lbs = unloaded_weight;
	}

	/**
	 * to calculate the gross income of all loaded packages
	 * 
	 * @param load
	 * @return double
	 */
	public double cal_gross_income(delivery_package load) {
		double revenue = getGross_income();

		revenue = revenue + load.getShipping_cost();

		return this.gross_income = revenue;

	}

	/**
	 * load method scans each package to verify if it is eligible to be loaded in
	 * the truck and throw exceptions when packages are not eligible
	 * 
	 * @param x
	 */
	public void load(delivery_package x) {
		boolean validation = true;

		try {

			if (x == null) {
				throw new NullPointerException("No reference");
			}
			if (getLoaded_nb_package() >= 200) {
				throw new Exception("Truck is full");
			}
			int y = 0;

			if (x.getClass() == letter.class) {
				y = 32;// ounce
				letter letterCast = (letter) x;
				this.loading[getLoaded_nb_package()] = new letter(letterCast);
				this.loading[getLoaded_nb_package()].toPounds(this.loading[getLoaded_nb_package()].getWeight());

			} else if (x.getClass() == box.class) {
				y = 40;
				box boxCast = (box) x;
				this.loading[getLoaded_nb_package()] = new box(boxCast);

			} else if (x.getClass() == wood_crate.class) {
				y = 80;
				wood_crate wood_crateCast = (wood_crate) x;
				this.loading[getLoaded_nb_package()] = new wood_crate(wood_crateCast);

			} else if (x.getClass() == crate_metal.class) {
				y = 100;
				crate_metal crate_metalCast = (crate_metal) x;
				this.loading[getLoaded_nb_package()] = new crate_metal(crate_metalCast);
			}

			else {
				throw new Exception("Invalid package type \n unknown package type");
			}

			if (x.getWeight() < 0 || x.getWeight() == 0 || x.getWeight() > y) {
				throw new Exception("invalid weight!\n");

			} else {
				System.out.println("Following Package loaded successfully!!!\n");
				System.out.println(this.loading[getLoaded_nb_package()] + "\n");
				setLoadingPackage(this.loading[getLoaded_nb_package()]);
				cal_gross_income(this.loading[getLoaded_nb_package()]);
				total_package_weight_lbs(this.loading[getLoaded_nb_package()]);
				validation = false;

				++loaded_nb_package;

			}
		} catch (NullPointerException e) {
			System.out
					.println("Cannot load the following package for the following reason: \n" + e.getMessage() + "\n");

		} catch (Exception e) {
			System.out
					.println("Cannot load the following package for the following reason: \n" + e.getMessage() + "\n");

		} finally {
			if (validation == true) {
				System.out.println(x.toString() + "\n");
			}
		}
	}
	/**
	 * use to remove a package from the truck 
	 * @param collie
	 */
	public void unload_truck(delivery_package collie) {
		System.out.println(collie);
		collie = null;
	//	setLoaded_nb_package(getLoaded_nb_package() - 1);
		System.out.println("After unloading the package: at index " + (getLoaded_nb_package() - 1) + " : " + collie);

	}
	/**
	 * getter for array of package
	 * @return
	 */
	public delivery_package[] getLoading() {

		return loading;
	}
	/**
	 * access number of package that is loaded 
	 * @return int
	 */
	public static int getLoaded_nb_package() {
		return loaded_nb_package;
	}
	/**
	 * edit nb of loaded package
	 * @param loaded_nb_package
	 */
	public static void setLoaded_nb_package(int loaded_nb_package) {
		truck.loaded_nb_package = loaded_nb_package;
	}
	/**
	 * access truck driver name
	 * @return
	 */
	public String getDriver_name() {
		return driver_name;
	}
	/**
	 * change driver name
	 * @param driver_name
	 */
	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}
	
	public String getOrigin_location() {
		return origin_location;
	}

	public void setOrigin_location(String origin_location) {
		this.origin_location = origin_location;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	

	/**
	 * access package info
	 * @param load
	 * @return delivery_package 
	 */
	public delivery_package getLoadingPackage(delivery_package load) {
		return load;
	}
	/**
	 * initialize package 
	 * @param loading
	 */
	public void setLoadingPackage(delivery_package loading) {
		this.loading[getLoaded_nb_package()] = loading;
	}
	/**
	 * access gross income
	 * @return double
	 */
	public double getGross_income() {
		return gross_income;
	}
	/**
	 * initialize or edit gross income
	 * @param gross_income
	 */
	public void setGross_income(double gross_income) {
		this.gross_income = gross_income;
	}

}
