//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.text.DecimalFormat;

/**
 * 
 * @author Michael
 *
 */
public abstract class delivery_package {
	/**
	 * instance variables for the parent abstract class
	 */
	private int [] tracking_nb;// encodes the origin and destination and type of package
	private double weight;
	private double shipping_cost;
	private String addInfo;
	/**
	 * default constructor for the parent class
	 */
	public delivery_package() {
		tracking_nb = null;
		weight = 0;
		shipping_cost = 0;
		addInfo=" ";
		truck.setLoaded_nb_package(truck.getLoaded_nb_package() + 1);
		
	}
	/**
	 * constructor for delivery_package
	 * @param weight
	 */
	public delivery_package(double weight) {
		this.weight=weight;
		generateTrackingNumber();
		calCost();
	}
	/**
	 * copy constructor for superclass
	 * @param anotherPackage
	 */
	public delivery_package( delivery_package anotherPackage) {
		this.tracking_nb=anotherPackage.tracking_nb;
		this.weight= anotherPackage.weight;
		this.shipping_cost=anotherPackage.shipping_cost; 
	}
	/**
	 * convert package weight into pounds
	 * @param item_weightOunce
	 */
	public void toPounds(double item_weightOunce) {
		setWeight(item_weightOunce/16);
		}
	/**
	 * method uses to convert package into ounces
	 * @param item_weightPounds
	 */
	public void toOunces(double item_weightPounds) {
		setWeight(item_weightPounds*16);
	}
	
/**
 * abstract method uses to verify if package has a valid weight to be loaded
 * @param weight
 * @return
 */
	public abstract boolean check_weight(double weight);
	
	/**
	 * display object
	 */
	public abstract String toString();
	/**
	 * 
	 * @return
	 */
	public abstract String getPackageType();
	/**
	 * method uses to generate a tracking number for each package
	 */
	public abstract void generateTrackingNumber();
	/**
	 * method uses to calculate the price
	 */
	public abstract void calCost();

	/**
	 * access the tracking number
	 * @return
	 */
	public int[] getTracking_nb() {
		int[] copyArray=new int[this.tracking_nb.length];
		System.arraycopy(this.tracking_nb,0,copyArray,0,copyArray.length);
		return copyArray;
	}
	/**
	 * 
	 * @param a
	 * @return
	 */
	public String toStringTrackingNb(int[] a) {
		return Arrays.toString(a);
	}
	/**
	 * mutator uses to to edit tracking number
	 * @param tracking_nb
	 */
	public void setTracking_nb(int[] tracking_nb) {
		this.tracking_nb = tracking_nb;
	}
	
	public String getAddInfo() {
		return addInfo;
	}

	public void setAddInfo(String addInfo) {
		this.addInfo = addInfo;
	}

	

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getShipping_cost() {
		return shipping_cost;
	}

	public void setShipping_cost(double shipping_cost) {
		this.shipping_cost = shipping_cost;
	}

}
