//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;

public class wood_crate extends crate{
	/**
	 * wood crate constructor with parameter weight
	 * @param weight
	 */
	public wood_crate(double weight) {
		super(weight);
	}
	/**
	 * copy constructor 
	 * @param anotherWCrate
	 */
	public wood_crate(wood_crate anotherWCrate) {
		super(anotherWCrate);
	}
	/**
	 * use to calculate the cost for shipping
	 */
	public void calCost() {
		setShipping_cost(getWeight()*2.5);
	}
	/**
	 * method uses to validate the weight to be loaded
	 */
	public boolean check_weight(double weight) {
		return (weight>0 && weight <=80);
	}
	public String getPackageType() {
		return "Wood Crate";
	}
	
	public String toString() {
		return "Package Type: " +getPackageType() + "\n Weight: "+ getWeight() +" lbs"+"\n shipping cost: "+getShipping_cost()+"$"+"\nTracking Number: "+toStringTrackingNb(getTracking_nb());
	}
	/**
	 * generate random shipping number with two at the end
	 */
	public void generateTrackingNumber() {
		int[] trackingNb = new int[10];

		for (int i = 0; i < 9; i++) {
			trackingNb[i] = (int) (Math.random() * (11 - 0));
	
		}
		trackingNb[9]=2;
		setTracking_nb(trackingNb);
	}
}
