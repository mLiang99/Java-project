//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;

public class crate extends delivery_package {
	/**
	 * crate constructor with parameter weight
	 * 
	 * @param weight
	 */
	public crate(double weight) {
		super(weight);
	}

	/**
	 * copy constructor
	 * 
	 * @param anotherCrate
	 */
	public crate(crate anotherCrate) {
		super(anotherCrate);
	}

	/**
	 * calculate the cost for shipping
	 * 
	 */
	public void calCost() {
		setShipping_cost(getWeight() * 3);
	}

	/**
	 * validate the weight before loading
	 * 
	 */
	public boolean check_weight(double weight) {
		return (weight > 0 && weight <= 100);
	}

	public String getPackageType() {
		return "Crate";
	}

	/**
	 * display object with all the attributes
	 */
	public String toString() {
		return "Package Type: " + getPackageType() + "\n Weight: " + getWeight() + " lbs" + "\n shipping cost: "
				+ getShipping_cost() + "$";
	}

	/**
	 * generate random shipping number with two at the end
	 */
	@Override
	public void generateTrackingNumber() {
		// TODO Auto-generated method stub

	}

}
