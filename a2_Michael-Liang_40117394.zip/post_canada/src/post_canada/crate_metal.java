//-------------------------------------------------------
// Assignment 2
// Part 1 
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package post_canada;

public class crate_metal extends crate {
/**
 * metal crate constructor with parameter weight
 * @param weight
 */
	public crate_metal(double weight) {
		super(weight);
	}
	/**
	 * copy constructor
	 * @param anotherCrateMetal
	 */
	public crate_metal(crate_metal anotherCrateMetal) {
		super(anotherCrateMetal);
	}
	/**
	 * method use to calculate the cost for shipping
	 */
	public void calCost() {
		setShipping_cost(getWeight()*3);
	}
	/**
	 * validate the weight before shipping
	 */
	public boolean check_weight(double weight) {
		return (weight > 0 && weight <= 100);
	}

	public String getPackageType() {
		return "Metal Crate";
	}
	/**
	 * display object with all the attributes
	 */
	public String toString() {
		return "Package Type: " + getPackageType() + "\n Weight: " + getWeight() + " lbs" + "\n shipping cost: "
				+ getShipping_cost() + "$" + "\nTracking Number: " + toStringTrackingNb(getTracking_nb());
	}
	/**
	 * generate random shipping number ending with a 3
	 */
	public void generateTrackingNumber() {
		int[] trackingNb = new int[10];
		// Random trackingNb[] = new Random();

		for (int i = 0; i < 9; i++) {
			trackingNb[i] = (int) (Math.random() * (11 - 0));

		}
		trackingNb[9] = 3;
		setTracking_nb(trackingNb);
	}

}
