//-------------------------------------------------------
// Assignment 2
// Part 2
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package cargoDestroyer_software;

public class cargoship {
	//instance variables for cargoship
	private long serial_nb;
	private String name;
	private int inaugurationYear;
	private String owner_country;
	private double price;
	private int speed;

	public cargoship() {//default constructor 
		this.serial_nb = 0000000000;
		this.name = null;
		this.inaugurationYear = 0000;
		this.owner_country = null;
		this.price = 0;
		this.speed = 0;

	}
	// constructor with attributes
	public cargoship(long ship_nb, String name, int initial_year, String owner, double price, int speed) {
		this.serial_nb = ship_nb;
		this.name = name;
		this.inaugurationYear = initial_year;
		this.owner_country = owner;
		this.price =price;
		this.speed = speed;

	}
	//display object
	public String toString() {
		return getSerial_nb() + " " + getName() + " " + getInaugurationYear() + " " + getOwner_country() + " "
				+ getPrice() + " " + getSpeed();
	}
	// accessors and mutators of instance variables
	public long getSerial_nb() {
		return serial_nb;
	}

	public void setSerial_nb(long serial_nb) {
		this.serial_nb = serial_nb;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getInaugurationYear() {
		return inaugurationYear;
	}

	public void setInaugurationYear(int inaugurationYear) {
		this.inaugurationYear = inaugurationYear;
	}

	public String getOwner_country() {
		return owner_country;
	}

	public void setOwner_country(String owner_country) {
		this.owner_country = owner_country;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

}
