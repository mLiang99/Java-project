//-------------------------------------------------------
// Assignment 2
// Part 2
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package cargoDestroyer_software;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class cargoshipInventory1 {
	private static cargoship[] wsArr;
	private static int nbObject;

	public static int getNbObject() {
		return nbObject;
	}

	public static void setNbObject(int nbObject) {
		cargoshipInventory1.nbObject = nbObject;
	}

	public cargoshipInventory1(cargoship[] shipNaval) {
		cargoshipInventory1.wsArr = new cargoship[getNbObject()];

	}

	/**
	 * method use to fix the duplicate serial number
	 * 
	 * @param inputFileStream
	 * @param outputFileStream
	 */
	public void countNbObject(String InputFileName) {
		Scanner read = null;
		int count = 0;
		String line = null;
		try {
			// System.out.println(new File("Initial_Cargoship_Info.txt").getAbsolutePath());
			read = new Scanner(new FileInputStream("Initial_Cargoship_Info.txt"));

		}

		catch (FileNotFoundException e) {
			System.out.println("file does not exist");
		}

		while (read.hasNextLine()) {// to read all object
			line = read.nextLine();

			// System.out.println("fsdf");
			count++;
		}
		setNbObject(count);
		read.close();
	}

	public String validationFileName() {
		Scanner keyboard = new Scanner(System.in);
		String newFileName = null;
		System.out.println("please enter a new file name (with following format: filename.txt ): ");
		File outputFile = null;

		do {
			newFileName = keyboard.nextLine();

			outputFile = new File(newFileName);
			if (outputFile.exists()) {
				System.out.println(
						"This file " + newFileName + " has a size of " + outputFile.getTotalSpace() + " bytes.");
				System.out.println("Please input a new path this file already exists");
			}
		} while (outputFile.exists());

		return newFileName;

	}

	public void readInputFile(String inputFileName) {
		Scanner read = null;
		int count = 0;
		cargoshipInventory1.wsArr = new cargoship[getNbObject()];
		try {
			countNbObject(inputFileName);

			read = new Scanner(new FileInputStream(inputFileName));

		}

		catch (FileNotFoundException e) {
			System.out.println("file does not exist error");
			// System.exit(0);
		}
		{
			long nb;
			String owner;
			String name;
			int year;
			double price;
			int speed;
			// to read all object
			for (count = 0; count < wsArr.length; count++) {
				nb = read.nextLong();
				name = read.next();
				year = read.nextInt();
				owner = read.next();
				price = read.nextDouble();
				speed = read.nextInt();
				wsArr[count] = new cargoship(nb, name, year, owner, price, speed);

			}
		}
		read.close();

	}

	public void writeOutputStream(String FileOutputName) {
		PrintWriter write = null;
		try {
			write = new PrintWriter(new FileOutputStream(FileOutputName));
			for (int i = 0; i < getNbObject(); i++) {
				write.println(wsArr[i].toString());

			}

		} catch (FileNotFoundException e) {
			System.out.println("file cant be opened");

		}
		write.close();
	}

	private void doubleCheckValidation() {
		Scanner keyboard = null;
		System.out.println("Double checking serial number please wait!\n");
		for (int i = 0; i < getNbObject() - 1; i++) {

			for (int j = i; j < getNbObject() - 1; j++) {

				if (wsArr[i].getSerial_nb() == wsArr[j + 1].getSerial_nb()) {

					boolean validNewNb = false;
					long newSerialNb = 0;

					while (true) {// try catch inside loop
						boolean quit = false;
						try {
							newSerialNb = keyboard.nextInt();
							for (int a = 0; a < j + 1; a++) {
								if ((wsArr[a].getSerial_nb() == newSerialNb)) {// validate user serial number
									validNewNb = false;
									throw new duplicateSerialNumberexception(
											"This serial number has been used already by another object.");

								}

							}
							validNewNb = true;
							quit = true;

						} catch (duplicateSerialNumberexception e) {

							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							System.out.println("Please input a long type with less than 9 digit");
							keyboard.nextLine();

						} catch (Exception e) {
							System.out.println(" Error exception");
							keyboard.nextLine();

						}
						if (quit) {
							break;
						}
					}

					if (validNewNb = true) {
						wsArr[j + 1].setSerial_nb(newSerialNb);

					}
				}
			}
		}
		System.out.println("Double check validation! all clear\n");

	}

	public void fixInventory(String inputFileStream, String outputFileStream) {
		Scanner read = null;
		PrintWriter write = null;
		Scanner keyboard = null;

		try {
			keyboard = new Scanner(System.in);
			read = new Scanner(new FileInputStream(inputFileStream));
			write = new PrintWriter(new FileOutputStream(outputFileStream));
		} catch (FileNotFoundException e) {
			System.out.println(" no such file");
		}
		try {

			readInputFile(inputFileStream);
			System.out.println("This initial file has " + getNbObject() + " objects.\n");
			for (int i = 0; i < getNbObject(); i++) {
				System.out.println(wsArr[i]);
			}
			System.out.println("\nLets analyze our data to see if we have duplicate serial numbers\n");
			for (int i = 0; i < getNbObject() - 1; i++) {

				for (int j = i; j < getNbObject() - 1; j++) {

					if (wsArr[i].getSerial_nb() == wsArr[j + 1].getSerial_nb()) {
						System.out.println(wsArr[j + 1].getName() + " located at index " + (j + 1)
								+ " has duplicate serial number of the following " + wsArr[j + 1].getSerial_nb());
						System.out.println("Please enter a new  serial number with at most 9 digits");
						boolean validNewNb = false;
						long newSerialNb = 0;

						while (true) {// try catch inside loop
							boolean quit = false;
							try {
								newSerialNb = keyboard.nextInt();
								for (int a = 0; a < j + 1; a++) {
									if ((wsArr[a].getSerial_nb() == newSerialNb)) {// validate user serial number
										validNewNb = false;
										throw new duplicateSerialNumberexception(
												"This serial number has been used already by another object.");

									}

								}
								validNewNb = true;
								quit = true;

							} catch (duplicateSerialNumberexception e) {

								System.out.println(e.getMessage());
							} catch (InputMismatchException e) {
								System.out.println("Please input a long type with less than 9 digit");
								keyboard.nextLine();

							} catch (Exception e) {
								System.out.println(" Error exception");
								keyboard.nextLine();

							}
							if (quit) {
								break;
							}
						}

						if (validNewNb = true) {
							wsArr[j + 1].setSerial_nb(newSerialNb);

						}
					}
				}
			}

		} catch (Exception e) {
			System.out.println("mismatch input");

		}
		doubleCheckValidation();
		System.out.println(
				"This is the corrected version of the file in which each warship has an unique serial numbers.\n");
		for (int i = 0; i < getNbObject(); i++) {
			System.out.println(wsArr[i]);
			writeOutputStream(outputFileStream);
		}

		read.close();
		write.close();
	}

	// should the method return an array of cargoship or an individual ship
	public void displayFileContents(String inputFileName) {
		Scanner read = null;
		int count = 0;
		cargoshipInventory1.wsArr = new cargoship[getNbObject()];
		try {
			countNbObject(inputFileName);

			read = new Scanner(new FileInputStream(inputFileName));

		}

		catch (FileNotFoundException e) {
			System.out.println("file does not exist error");
			// System.exit(0);
		}
		{
			long nb;
			String owner;
			String name;
			int year;
			double price;
			int speed;
			// to read all object
			for (count = 0; count < wsArr.length; count++) {
				nb = read.nextLong();
				name = read.next();
				year = read.nextInt();
				owner = read.next();
				price = read.nextDouble();
				speed = read.nextInt();
				wsArr[count] = new cargoship(nb, name, year, owner, price, speed);
				System.out.println(wsArr[count]);

			}
		}
		read.close();

	}

	

	public static cargoship[] getWsArr() {
		return wsArr;
	}

	public static void setWsArr(cargoship[] wsArr) {
		cargoshipInventory1.wsArr = wsArr;
	}

}
