//-------------------------------------------------------
// Assignment 2
// Part 2
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
/**
//Michael Liang 40117394
//COMP 249
// Assignment 2 part 2
// July 26, 2020
 */

/**
 * This program edits any duplicated serial numbers from a text file and outputs another text file with an unique serial number for each warship.
 */
package cargoDestroyer_software;

import java.util.Scanner;

public class cargoFile_driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner keyboard = new Scanner(System.in);
		cargoshipInventory1 naval = null;
		naval = new cargoshipInventory1(new cargoship[naval.getNbObject()]);
		System.out.println("Hello World and Welcome to the USS Destroyer Top Secret Data Base!\n");
		naval.countNbObject("Initial_Cargoship_Info.txt");

		if (naval.getNbObject() == 0) {
			System.out.println(
					"There is no warship in this mission therefore no serial number can be accessed or modify");
		} else if (naval.getNbObject() == 1) {
			System.out.println(
					"In this mission there is only one warship therefore a duplicate serial number cannot exists");

		} else {
			naval.fixInventory("Initial_Cargoship_Info.txt", naval.validationFileName());
			System.out.println("\nThank you for your collaboration and remember dont talk to anyone!");
			
		}

	}

}
