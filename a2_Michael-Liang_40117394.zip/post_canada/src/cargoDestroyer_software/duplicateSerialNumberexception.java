//-------------------------------------------------------
// Assignment 2
// Part 2
// Written by: Michael Liang 40117394
// For COMP 249 Summer 2
// July 26, 2020
// ------------------------------------------------------
package cargoDestroyer_software;

public class duplicateSerialNumberexception extends Exception{
	// exceptions that is thrown when a serial number is duplicate
	public duplicateSerialNumberexception() {
		super("This serial number exists already for another object.");
	}
	public duplicateSerialNumberexception(String message) {
		super(message);
	}
}
